import { NextRequest } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { audit } from "@/lib/notify";
import { getOrderedKeys } from "@/lib/ai/keyPool";
import { generateVeoClip, getVeoEngine } from "@/lib/ai/veo";
import { run } from "@/lib/pipeline/render";
import { checkFfmpegReady, ffmpegStatusError } from "@/lib/pipeline/ffmpegCheck";
import os from "os";
import path from "path";
import fs from "fs/promises";

/**
 * POST /api/v1/admin/veo/test — verify the Veo cinematic-motion setup end to end.
 *
 * Generates ONE short (4 s) clip from a solid test card using the current engine
 * and the admin key pool, and returns the EXACT provider result so the admin can
 * see why Flow-style motion is (or is not) working:
 *   - no keys pooled        → actionable error
 *   - billing not enabled   → Google's real rejection message
 *   - success               → model used + clip size
 * A successful test consumes a single short Veo clip (cheap, veo-3.0-fast family).
 */
export const POST = handler(async (req: NextRequest) => {
  const admin = await requireAdmin(req);

  const keys = await getOrderedKeys().catch(() => [] as string[]);
  if (keys.length === 0) {
    return ok({
      ok: false,
      reason: "no_keys",
      error:
        "No Gemini API keys in the account pool. Add at least one billing-enabled key (Admin → API & Integrations → Gemini account pool) — Veo is paid-only and cannot run on free-tier keys.",
    });
  }

  const ff = await checkFfmpegReady();
  if (!ff.ok) {
    return ok({ ok: false, reason: "ffmpeg", error: ffmpegStatusError(ff).message });
  }

  const engine = await getVeoEngine();
  const tmp = path.join(os.tmpdir(), `veo_test_${Date.now()}.png`);
  const started = Date.now();
  try {
    // 512×896 (9:16) solid violet test card — a valid, properly sized image
    await run("ffmpeg", ["-y", "-f", "lavfi", "-i", "color=c=0x7C3AED:s=512x896", "-frames:v", "1", tmp], 30_000, {
      label: "creating Veo test image",
    });
    const image = await fs.readFile(tmp);
    const { video, model, key } = await generateVeoClip({
      image,
      mimeType: "image/png",
      prompt:
        "Test clip: a calm solid violet background with very subtle light drift. One smooth slow push-in. No text, no people, no effects.",
      seconds: 4,
      maxWaitMs: 150_000,
      engine,
    });
    const ms = Date.now() - started;
    await audit(admin, "admin.veo.test", "appSetting", undefined, { ok: true, model, ms });
    return ok({
      ok: true,
      model,
      key,
      engine,
      seconds: Math.round(ms / 1000),
      clipKb: Math.round(video.length / 1024),
      note: "Veo is working — renders will use real Flow-style AI motion for every scene.",
    });
  } catch (e) {
    const raw = e instanceof Error ? e.message : String(e);
    const msg = raw.slice(0, 400);
    const lower = raw.toLowerCase();
    const reason = lower.includes("billing")
      ? "billing"
      : lower.includes("quota") || lower.includes("429")
        ? "quota"
        : lower.includes("api key") || lower.includes("401") || lower.includes("403")
          ? "key"
          : "provider";
    await audit(admin, "admin.veo.test", "appSetting", undefined, { ok: false, reason, msg });
    return ok({
      ok: false,
      reason,
      engine,
      error:
        reason === "billing"
          ? `Google rejected Veo: billing is not enabled on this API key's project. Enable billing for the project in Google AI Studio / Cloud Console, then retest. Raw: ${msg}`
          : msg,
    });
  } finally {
    fs.rm(tmp, { force: true }).catch(() => {});
  }
});
