import { NextRequest } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { generateVeoClip, cinematicMotionDirective } from "@/lib/ai/veo";
import { getGeminiKeyPool } from "@/lib/ai/keyPool";

/**
 * POST /api/v1/admin/veo/test — real end-to-end Veo connectivity test.
 * Queues a tiny 4-second image-to-video clip through the admin key pool
 * (same code path renders use), so the admin can confirm the Flow-style
 * cinematic motion works before enabling it for real renders.
 * Takes ~30-90s on keys with Veo access; fails fast (404/403) when the
 * account has no Veo quota.
 */
export const POST = handler(async (req: NextRequest) => {
  await requireAdmin(req);

  const pool = await getGeminiKeyPool().catch(() => [] as string[]);
  if (pool.length === 0) {
    return ok({
      ok: false,
      error:
        "No Gemini API keys configured — add at least one key with Veo access in the Gemini account pool above.",
    });
  }

  const started = Date.now();
  try {
    // Minimal 9:16 test frame (plain PNG — no dependency on generated assets)
    const { default: sharp } = await import("sharp");
    const image = await sharp({
      create: {
        width: 768,
        height: 1344,
        channels: 3,
        background: { r: 24, g: 28, b: 44 },
      },
    })
      .png()
      .toBuffer();

    const prompt =
      "A calm midnight-blue studio background with soft golden light particles drifting upward, one warm key light slowly sweeping across the frame. " +
      cinematicMotionDirective("veo3");

    const { video, model } = await generateVeoClip({
      image,
      mimeType: "image/png",
      prompt,
      seconds: 4,
      maxWaitMs: 3 * 60_000,
    });

    return ok({
      ok: true,
      model,
      seconds: Math.round((Date.now() - started) / 1000),
      clipKb: Math.round(video.length / 1024),
      note: "Renders will use this real Flow-style motion instead of static zoom.",
    });
  } catch (e) {
    const msg = (e instanceof Error ? e.message : String(e)).slice(0, 300);
    return ok({
      ok: false,
      seconds: Math.round((Date.now() - started) / 1000),
      error: msg,
    });
  }
});
