import { NextRequest } from "next/server";
import { z } from "zod";
import { requireAdmin } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { audit } from "@/lib/notify";
import { getGeminiKey, invalidateAiConfigCache } from "@/lib/ai/config";
import { setSettingValue } from "@/lib/payments";

/**
 * Gemini key helpers — verify against the live API (cheap models.list call)
 * before persisting, so a broken key never silently degrades generation.
 */

const clean = (key: string) => key.trim().replace(/^["']|["']$/g, "");

async function verifyKey(apiKey: string): Promise<{ valid: boolean; message: string }> {
  const key = clean(apiKey);
  if (!key) return { valid: false, message: "No API key provided." };
  try {
    const res = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models?pageSize=1",
      { headers: { "x-goog-api-key": key }, signal: AbortSignal.timeout(15000) }
    );
    if (res.ok) {
      return { valid: true, message: "Gemini key verified — it is live and working." };
    }
    const body = (await res.json().catch(() => ({}))) as { error?: { message?: string } };
    const detail = body.error?.message ?? "";
    if (res.status === 400 || res.status === 401 || res.status === 403) {
      return { valid: false, message: `Key rejected by Google (${res.status}). ${detail.slice(0, 180)}` };
    }
    return { valid: false, message: `Gemini API error ${res.status}. ${detail.slice(0, 180)}` };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return { valid: false, message: `Could not reach Gemini (${msg.slice(0, 140)}). Check the network and try again.` };
  }
}

const putSchema = z.object({
  apiKey: z.string().min(20).max(300).optional(),
});

/**
 * PUT /api/v1/admin/ai/test — VERIFY & SAVE.
 * Verifies the provided key against the Gemini API; only persists it (AES-256-GCM
 * encrypted) when the key actually works.
 */
export const PUT = handler(async (req: NextRequest) => {
  const admin = await requireAdmin(req);
  const body = await parseBody(req, putSchema);
  if (!body.apiKey) {
    return ok({ valid: false, saved: false, message: "Paste a Gemini API key first (free: aistudio.google.com/apikey)." });
  }
  const result = await verifyKey(body.apiKey);
  if (!result.valid) {
    return ok({ valid: false, saved: false, message: result.message });
  }
  await setSettingValue("gemini_api_key", clean(body.apiKey), true);
  invalidateAiConfigCache();
  await audit(admin, "admin.ai.key.verify_save", "appSetting", "gemini_api_key", { valid: true });
  return ok({ valid: true, saved: true, message: "Gemini key verified and saved (encrypted at rest)." });
});

/**
 * POST /api/v1/admin/ai/test — TEST the stored key against the live API.
 */
export const POST = handler(async (req: NextRequest) => {
  const admin = await requireAdmin(req);
  const stored = await getGeminiKey().catch(() => null);
  if (!stored) {
    return ok({ valid: false, message: "No Gemini key stored yet — paste one and click “Verify & save”." });
  }
  const result = await verifyKey(stored);
  await audit(admin, "admin.ai.key.test", "appSetting", "gemini_api_key", { valid: result.valid }).catch(() => {});
  return ok({ valid: result.valid, message: result.valid ? result.message : `Stored key FAILED: ${result.message}` });
});
